package com.demo.constants;

/**
 * @author Anand
 */
public class CustomLogoutPortletKeys {

	public static final String CUSTOMLOGOUT =
		"com_demo_CustomLogoutPortlet";

}